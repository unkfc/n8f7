Welcome to Synapse X! We are glad to have you here.

To start, run Synapse X.exe.

If you need any help, you can contact support at https://synapsesupport.io/.

Enjoy!